
/* StudySapiens service worker. V1 */
const VERSION = 'ss-v13';
const CORE = [
  './', 'classes/', 'pairing-scheme/', 'mdcat/', 'date-sheet/', 'offline/',
  'assets/css/style.css', 'assets/js/main.js',
  'assets/img/logo-trim-light.png', 'assets/img/mark.png', 'assets/img/favicon-32.png',
  'assets/img/favicon-64.png', 'assets/img/favicon-180.png', 'assets/img/hero-1300.webp',
  'assets/img/og-image.jpg', 'site.webmanifest'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('message', e => {
  if (e.data && e.data.type === 'CACHE_URLS' && Array.isArray(e.data.urls)) {
    caches.open(VERSION).then(c => c.addAll(e.data.urls)).catch(() => {});
  }
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Pages: network-first, fall back to cache, then the offline page
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(res => {
      const copy = res.clone();
      caches.open(VERSION).then(c => c.put(req, copy));
      return res;
    }).catch(() => caches.match(req).then(cached => cached || caches.match('offline/'))));
    return;
  }

  // Assets (css/js/img/fonts incl. Google Fonts): stale-while-revalidate
  e.respondWith(caches.match(req).then(cached => {
    const network = fetch(req).then(res => {
      if (res && (res.ok || res.type === 'opaque')) {
        const copy = res.clone();
        caches.open(VERSION).then(c => c.put(req, copy));
      }
      return res;
    }).catch(() => cached);
    return cached || network;
  }));
});
