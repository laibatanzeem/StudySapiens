/* ==========================================================================
   StudySapiens · ss-config.js — SITE SETTINGS (the only file you edit here)
   --------------------------------------------------------------------------
   TWO places, one rule — this file is the BUILD SOURCE (assets/js/
   ss-config.js); the build copies it to site/assets/js/ss-config.js and
   into site.zip.
   • Quickest (live site): edit site/assets/js/ss-config.js in your host's
     File Manager — the service worker fetches it network-first, so the
     change applies on the next page view. No re-upload needed.
   • BUT the next full zip upload OVERWRITES the server copy — so ALSO
     paste the same values here (or send them to whoever builds the zip)
     so they survive every rebuild. Everything below is public-by-design,
     so keeping them in the repo is safe.
   Until a value is empty, that form safely falls back to opening the
   visitor's email app (the old behaviour), so the site never breaks.

   ⚠ SAFETY: only paste values that are MEANT to be public (form URLs and
   website "access keys"). NEVER paste a secret API key from any service —
   everything in this file is visible in the visitor's browser.
   ========================================================================== */
window.SS_CONFIG = {

  /* File version - bump this and add a line to the CHANGELOG at the
     bottom of this file whenever you change any value here. */
  configVersion: "1.0",

  /* ---- CONTACT FORM (Web3Forms — free, no account needed) --------------
     1. Go to  https://web3forms.com
     2. Enter  admin@studysapiens.com  and submit.
     3. They email you an "Access Key" (a short code). Paste it below.
     Contact messages then arrive straight in that inbox, with spam
     filtering + our hidden honeypot field blocking bots.                 */
  contactEndpoint: "https://api.web3forms.com/submit",
  contactAccessKey: "",            // <-- paste your Web3Forms access key here

  /* ---- NEWSLETTER (your ESP: MailerLite / Brevo / Buttondown / Kit…) ---
     Recommended: MailerLite (free up to 1,000 subscribers, double opt-in
     built in). In your ESP, create an embedded/sign-up form, then copy its
     form ACTION URL (the address inside  <form action="...">  of the embed
     code) and paste it below.

     - Buttondown / Brevo / Kit forms use field name "email"  → leave
       newsletterEmailField as "email".
     - MailerLite embeds use  fields[email]  → change it to "fields[email]".
     - If the embed code contains hidden inputs (e.g. groups[] or list ids),
       copy them into newsletterFields below.

     In your ESP settings, turn DOUBLE OPT-IN ON (confirmation email) —
     the site's success message already tells students to expect it.      */
  newsletterEndpoint: "",          // <-- paste your ESP form action URL here
  newsletterEmailField: "email",   // MailerLite: "fields[email]"
  newsletterFields: {},            // e.g. { "groups[]": "1234567890" }

  /* Fallback address used when the values above are still empty: */
  notifyEmail: "admin@studysapiens.com",

  /* ---- COOKIE BANNER (Google Consent Mode v2) --------------------------
     true  = our first-party banner asks visitors and sets Consent Mode
             signals (analytics + ads, with a "necessary only" option).
     false = you have switched to a Google-certified CMP (e.g. the free
             "Privacy & messaging" CMP inside AdSense, or CookieYes/Cookiebot).
             Set this to false on the SAME DAY you enable that CMP so
             visitors do not see two banners.                                  */
  consentBanner: true

  /* ---- CHANGELOG ----------------------------------------------------------
     v1.0  15 Nov 2026  Initial versioned config. contactAccessKey and
           newsletterEndpoint still empty -> forms use the mailto fallback,
           and page copy shows honest fallback wording (upgraded
           automatically in the browser once keys are pasted).
           consentBanner: true (first-party Consent Mode v2 banner).      */
};
